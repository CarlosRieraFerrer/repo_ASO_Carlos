#!/bin/bash

USER=$1
GROUP=$(id -Gn $USER | grep -qw Docente_A3 && echo "Docente" || echo "Otro")

echo $GROUP >> /tmp/grupo.txt
if [ "$GROUP" == "Docente" ]; then
    MOUNT_OPTIONS="username=nasw,password=n4sw"
#else
#    MOUNT_OPTIONS="username=nas,password=nas"
fi

# Create the mount options configuration file
echo "volume user=\"$USER\" fstype=\"cifs\" server=\"192.168.225.7\" path=\"assignatura\" mountpoint=\"/mnt/assignatura\" options=\"$MOUNT_OPTIONS,uid=$USER,gid=$USER\"" > /etc/security/mount_options.conf

exit 0
