usuario=$USER
sudo /usr/sbin/update-groups.sh $usuario
sudo /usr/sbin/multiuser-docker.sh $usuario
sudo /usr/sbin/reseteo-docker.sh $usuario
